'use strict';

/**
 * CONFIGURARE — completează datele reale înainte de publicare.
 * Câmpurile goale nu sunt afișate vizitatorilor. Nu adăuga date inventate.
 */
const SITE_CONFIG = {
  email: '',
  phone: '',
  facebookUrl: '',
  instagramUrl: ''
};

/**
 * Catalog de prezentare: titlurile, autorii și genurile pot fi editate aici.
 * Coperțile sunt interpretări grafice, nu fotografii ale edițiilor tipărite.
 * Prețurile, disponibilitatea și stocurile nu sunt afișate fără confirmare.
 */
const BOOKS = [
  { id: 'dor-de-zbor', title: 'Dor de zbor', author: 'Victoria Guțu', category: 'poezie', art: 'book-style-sky', symbol: '✧' },
  { id: 'autograful-lacrimii', title: 'Autograful lacrimii', author: 'Victoria Guțu', category: 'poezie', art: 'book-style-ivory', symbol: '✒' },
  { id: 'taceri-cu-glas-de-vers', title: 'Tăceri cu glas de vers', author: 'Victoria Munteanu', category: 'poezie', art: 'book-style-teal', symbol: '❦' },
  { id: 'aburi-de-copilarie', title: 'Aburi de copilărie', author: 'Luminița Melnic', category: 'poezie', art: 'book-style-pink', symbol: '☼' },
  { id: 'pomul-cu-pere-de-aur', title: 'Pomul cu pere de aur', author: 'Dumitru Mircea', category: 'proză', art: 'book-style-gold', symbol: '♣' },
  { id: 'calea-spre-muntele-de-aur', title: 'Calea spre muntele de aur', author: 'Dumitru Mircea', category: 'proză', art: 'book-style-rust', symbol: '△' },
  { id: 'aplecat-peste-intrebarile-lumii', title: 'Aplecat peste întrebările lumii', author: 'Vlad Loghin', category: 'reflecții', art: 'book-style-slate', symbol: '?' },
  { id: 'lumina-din-glastra', title: 'Lumina din glastră', author: 'Victoria Guțu', category: 'poezie', art: 'book-style-night', symbol: '✺' }
];

const el = id => document.getElementById(id);
const grid = el('catalog-grid');
const filters = Array.from(document.querySelectorAll('[data-filter]'));
const searchField = el('catalog-search');
const drawer = el('request-drawer');
const backdrop = el('drawer-backdrop');
let activeFilter = 'toate';
let toastTimeout;
let previousFocus = null;

function readSavedList() {
  try {
    const stored = JSON.parse(localStorage.getItem('ancestrala-book-list') || '[]');
    return Array.isArray(stored) ? stored.filter(id => BOOKS.some(book => book.id === id)) : [];
  } catch (_) { return []; }
}
let selectedBooks = readSavedList();

function persistList() {
  try { localStorage.setItem('ancestrala-book-list', JSON.stringify(selectedBooks)); } catch (_) {}
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

function normalize(value) {
  return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('ro');
}

function renderBooks() {
  const needle = normalize(searchField.value.trim());
  const visible = BOOKS.filter(book =>
    (activeFilter === 'toate' || book.category === activeFilter) &&
    normalize(`${book.title} ${book.author} ${book.category}`).includes(needle)
  );
  if (!visible.length) {
    grid.innerHTML = '<p class="empty-catalog">Nu am găsit titluri pentru această căutare. Încearcă un alt cuvânt.</p>';
    return;
  }
  grid.innerHTML = visible.map(book => {
    const added = selectedBooks.includes(book.id);
    return `<article class="catalog-card">
      <div class="book-art"><div class="card-book ${book.art}" aria-label="Copertă grafică ilustrativă: ${escapeHTML(book.title)}">
        <span class="card-book-author">${escapeHTML(book.author.toLocaleUpperCase('ro'))}</span>
        <span class="card-book-symbol" aria-hidden="true">${escapeHTML(book.symbol)}</span>
        <span class="card-book-title">${escapeHTML(book.title)}</span>
        <span class="card-book-imprint">ANCESTRALA</span>
      </div></div>
      <div class="catalog-card-body">
        <span class="catalog-category">${escapeHTML(book.category)}</span>
        <h3>${escapeHTML(book.title)}</h3>
        <p class="catalog-author">${escapeHTML(book.author)}</p>
        <div class="catalog-card-foot"><span class="catalog-availability">Detalii la solicitare</span>
          <button type="button" class="catalog-add" data-add="${book.id}" aria-pressed="${added}" aria-label="${added ? 'Elimină din listă' : 'Adaugă în listă'}: ${escapeHTML(book.title)}">${added ? '✓ În lista mea' : '+ Adaugă în listă'}</button>
        </div>
      </div>
    </article>`;
  }).join('');
}

function updateList() {
  el('list-count').textContent = selectedBooks.length;
  persistList();
  renderBooks();
  renderDrawer();
}

function renderDrawer() {
  const books = selectedBooks.map(id => BOOKS.find(book => book.id === id)).filter(Boolean);
  const drawerItems = el('drawer-items');
  drawerItems.innerHTML = books.length ? books.map(book => `<div class="drawer-item"><div><strong>${escapeHTML(book.title)}</strong><small>${escapeHTML(book.author)}</small></div><button type="button" data-remove="${book.id}" aria-label="Elimină ${escapeHTML(book.title)}">Elimină</button></div>`).join('') : '<p class="drawer-empty">Lista ta de lectură așteaptă prima carte. ✧</p>';
  el('copy-request').disabled = !books.length;
  el('copy-request').style.opacity = books.length ? '1' : '.45';
  el('clear-request').hidden = !books.length;
}

function toast(message) {
  const node = el('toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => node.classList.remove('show'), 3500);
}

function openDrawer() {
  previousFocus = document.activeElement;
  drawer.hidden = false;
  backdrop.hidden = false;
  document.body.classList.add('no-scroll');
  el('drawer-status').textContent = '';
  el('close-drawer').focus();
}

function closeDrawer() {
  if (drawer.hidden) return;
  drawer.hidden = true;
  backdrop.hidden = true;
  document.body.classList.remove('no-scroll');
  if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
}

async function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    try { await navigator.clipboard.writeText(text); return true; } catch (_) {}
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.style.cssText = 'position:fixed;left:-99999px;top:0;';
  document.body.appendChild(area);
  area.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (_) {}
  area.remove();
  return ok;
}

function buildListMessage() {
  const lines = selectedBooks.map((id, index) => {
    const book = BOOKS.find(item => item.id === id);
    return book ? `${index + 1}. ${book.title} — ${book.author}` : '';
  }).filter(Boolean);
  return `Bună ziua, Editura și Librăria Ancestrala!\n\nAș dori informații despre următoarele cărți:\n${lines.join('\n')}\n\nVă rog să îmi comunicați disponibilitatea și prețurile.\n\nMulțumesc!`;
}

// Catalog: filters, search and book list.
filters.forEach(button => button.addEventListener('click', () => {
  activeFilter = button.dataset.filter;
  filters.forEach(item => { const on = item === button; item.classList.toggle('active', on); item.setAttribute('aria-pressed', String(on)); });
  renderBooks();
}));
searchField.addEventListener('input', renderBooks);
grid.addEventListener('click', event => {
  const button = event.target.closest('[data-add]');
  if (!button) return;
  const id = button.dataset.add;
  const book = BOOKS.find(item => item.id === id);
  if (!book) return;
  if (selectedBooks.includes(id)) {
    selectedBooks = selectedBooks.filter(item => item !== id);
    toast(`„${book.title}” a fost eliminată din listă.`);
  } else {
    selectedBooks.push(id);
    toast(`„${book.title}” a fost adăugată în listă.`);
  }
  updateList();
});

el('list-toggle').addEventListener('click', openDrawer);
el('close-drawer').addEventListener('click', closeDrawer);
backdrop.addEventListener('click', closeDrawer);
el('drawer-items').addEventListener('click', event => {
  const button = event.target.closest('[data-remove]');
  if (!button) return;
  selectedBooks = selectedBooks.filter(id => id !== button.dataset.remove);
  updateList();
});
el('clear-request').addEventListener('click', () => {
  selectedBooks = [];
  updateList();
  el('drawer-status').textContent = 'Lista a fost golită.';
});
el('copy-request').addEventListener('click', async () => {
  if (!selectedBooks.length) return;
  const ok = await copyText(buildListMessage());
  el('drawer-status').textContent = ok ? 'Solicitarea a fost copiată. O poți trimite editurii.' : 'Copierea nu a reușit. Încearcă dintr-un browser actualizat.';
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeDrawer();
  if (event.key !== 'Tab' || drawer.hidden) return;
  const focusable = Array.from(drawer.querySelectorAll('button:not(:disabled):not([hidden]),a[href],input:not(:disabled)')).filter(node => node.getClientRects().length);
  const first = focusable[0], last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
});

// Mobile navigation.
const menu = el('menu-toggle');
const nav = el('main-nav');
function closeMenu() {
  nav.classList.remove('open');
  menu.setAttribute('aria-expanded', 'false');
  menu.setAttribute('aria-label', 'Deschide meniul');
}
menu.addEventListener('click', () => {
  const on = nav.classList.toggle('open');
  menu.setAttribute('aria-expanded', String(on));
  menu.setAttribute('aria-label', on ? 'Închide meniul' : 'Deschide meniul');
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
window.addEventListener('resize', () => { if (window.innerWidth > 990) closeMenu(); });

// Contact links appear only after real information is supplied.
const contactDetails = el('contact-details');
if (SITE_CONFIG.email) {
  const link = document.createElement('a');
  link.className = 'contact-detail-link';
  link.href = `mailto:${SITE_CONFIG.email}`;
  link.textContent = `✉ ${SITE_CONFIG.email}`;
  contactDetails.appendChild(link);
}
if (SITE_CONFIG.phone) {
  const link = document.createElement('a');
  link.className = 'contact-detail-link';
  link.href = `tel:${SITE_CONFIG.phone.replace(/[^+0-9]/g, '')}`;
  link.textContent = `☏ ${SITE_CONFIG.phone}`;
  contactDetails.appendChild(link);
}
for (const [label, url] of [['Facebook', SITE_CONFIG.facebookUrl], ['Instagram', SITE_CONFIG.instagramUrl]]) {
  if (!url) continue;
  try {
    const parsed = new URL(url);
    if (!['https:', 'http:'].includes(parsed.protocol)) continue;
    const link = document.createElement('a');
    link.className = 'contact-detail-link';
    link.href = parsed.href;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = `${label} ↗`;
    contactDetails.appendChild(link);
  } catch (_) {}
}
if (!contactDetails.childElementCount) contactDetails.hidden = true;

function composeContactMessage() {
  const name = el('contact-name').value.trim();
  const topic = el('contact-topic').value;
  const message = el('contact-message').value.trim();
  if (!name || !message) return null;
  return `Bună ziua, Editura și Librăria Ancestrala!\n\nSubiect: ${topic}\nNume: ${name}\n\n${message}\n\nVă mulțumesc!`;
}
el('contact-form').addEventListener('submit', event => {
  event.preventDefault();
  const message = composeContactMessage();
  if (!message) return;
  el('prepared-message').value = message;
  el('form-output').hidden = false;
  el('form-status').textContent = 'Mesajul este pregătit. Copiază-l și trimite-l prin canalul dorit.';
  const emailLink = el('email-message');
  if (SITE_CONFIG.email) {
    emailLink.hidden = false;
    emailLink.href = `mailto:${SITE_CONFIG.email}?subject=${encodeURIComponent(el('contact-topic').value)}&body=${encodeURIComponent(message)}`;
  } else emailLink.hidden = true;
  el('prepared-message').focus();
});
el('copy-message').addEventListener('click', async () => {
  const ok = await copyText(el('prepared-message').value);
  el('form-status').textContent = ok ? 'Mesaj copiat. Îl poți trimite prin e-mail sau mesagerie.' : 'Nu s-a putut copia automat. Selectează textul de mai sus pentru copiere manuală.';
});

el('year').textContent = new Date().getFullYear();
updateList();
