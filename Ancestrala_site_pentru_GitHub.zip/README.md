# Editura & Librăria Ancestrala — site web

Site static, modern, responsive, în limba română. Poate fi publicat gratuit prin **GitHub Pages**, fără instalări de pachete, compilare sau server.

## Fișiere

- `index.html` — structura paginii, texte, secțiuni și meta-informații
- `styles.css` — aspect vizual pentru telefon, tabletă și calculator
- `main.js` — căutarea și filtrarea cărților, lista de interes, formularul de contact
- `assets/ancestrala.webp` — emblema editurii (din imaginea transmisă)
- `assets/roua-stelara.webp` — emblema revistei (din imaginea transmisă)
- `assets/favicon.png` — pictograma site-ului
- `.nojekyll` — pentru GitHub Pages

## Ce funcționează

- Meniu pentru mobil și navigație între secțiuni.
- Catalog cu titluri, autori, căutare și filtre pentru genuri.
- „Lista mea”: adaugi/elimini titluri, lista se păstrează local în browser, poți copia solicitarea.
- Formular care **pregătește** un mesaj și permite copierea acestuia. Dacă setezi e-mailul editurii, apare și butonul „Trimite prin e-mail”, care deschide aplicația de e-mail a vizitatorului.
- Secțiuni pentru servicii editoriale și revista *Roua Stelară*.
- Design adaptat pentru telefon și calculator; accesibilitate de bază (contrast, etichete, navigare din tastatură).

**Important:** acest site nu include plăți, stocuri, conturi de clienți ori expedierea automată a mesajelor. Niciun formular nu stochează date pe server. Titlurile catalogului sunt o selecție editorială de prezentare; imaginile lor sunt ilustrații stilizate, nu fotografii ale coperților reale. Verificați disponibilitatea și prețurile înainte de publicare.

## Completează datele reale înainte de publicare

În partea de sus a fișierului `main.js`, modifică:

```js
const SITE_CONFIG = {
  email: 'adresa-reala@exemplu.md',
  phone: '+373 ...',
  facebookUrl: 'https://www.facebook.com/pagina-reala',
  instagramUrl: ''
};
```

Acestea sunt **exemple de format**, nu date reale. Dacă lași un câmp gol, acesta nu va fi afișat. Adresa de e-mail activează linkul de trimitere din formular.

În `main.js`, modifică tabloul `BOOKS` pentru a adăuga/șterge cărți și actualiza numele autorilor sau genurile literare. Pentru fotografii reale ale coperților, adaugă fișierele în `assets/` și adaptează șablonul cărților din funcția `renderBooks()`.

## Cum îl publici pe GitHub Pages

1. Autentifică-te la contul GitHub `ancestrala`.
2. Creează un depozit public nou numit **`ancestrala.github.io`**, *dacă este disponibil*. Dacă există deja unul cu acest nume, verifică-l înainte de a suprascrie orice.
3. Încarcă **conținutul** acestui dosar la rădăcina depozitului: `index.html`, `styles.css`, `main.js`, `.nojekyll` și dosarul `assets/`.
4. În depozit, mergi la **Settings → Pages → Build and deployment**. Alege **Deploy from a branch**, ramura **main**, directorul **/(root)** și salvează.
5. Adresa site-ului pentru un depozit numit `ancestrala.github.io` ar trebui să fie `https://ancestrala.github.io/`. Pentru alte nume, GitHub Pages folosește, de regulă, adresa `https://ancestrala.github.io/nume-depozit/`.

Aceste instrucțiuni nu publică automat fișierele. Nu a fost efectuată nicio modificare în contul GitHub.

## Testare locală

Deschide `index.html` într-un browser. Site-ul nu are nevoie de o instalare suplimentară. Fonturile Google se încarcă dacă există acces la internet; în lipsa acestuia se folosesc fonturi de rezervă.

## Drepturi și identitate

Emblemele Editurii Ancestrala și Revistei Roua Stelară sunt preluate din materialele furnizate de utilizator. Conținutul demo nu reprezintă o declarație privind drepturile asupra titlurilor sau disponibilitatea lor comercială.
